import React, { lazy, Suspense } from 'react';
import { Routes, Route } from 'react-router-dom';

const Home = lazy(() => import('./pages/Home/Home'));
const Education = lazy(() => import('./pages/Education/index'));
const About = lazy(() => import('./pages/About/about'));
const Skills = lazy(()=> import('./pages/Skills/index'))
const Projects = lazy(() => import('./pages/Projects/index'));
const Contact = lazy(() => import('./pages/Contact/index'));

const AppRoutes = () => (
  <Suspense fallback={<div>Loading...</div>}>
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/about" element={<About />} />
      <Route path="/education" element={<Education />} />
      <Route path="/skills" element={<Skills />} />
      <Route path="/projects" element={<Projects />} />
      <Route path="/contact" element={<Contact />} />
    </Routes>
  </Suspense>
);

export default AppRoutes;