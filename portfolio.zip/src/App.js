import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import Header from './Layouts/Header/Header';
import SideNav from './Layouts/SideNav/SideNav';
import Footer from './Layouts/Footer/Footer';
import AppRoutes from './AppRoutes';
import { PageTitleProvider } from './context/PageTitleContext';
import Box from '@mui/material/Box';
import { useTheme, useMediaQuery } from '@mui/material';

const HEADER_HEIGHT = 64;
const SIDENAV_WIDTH = 150;

function App() {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  return (
    <Router>
      <PageTitleProvider>
      
        <Box
          sx={{
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100%',
            zIndex: 1300,
            bgcolor: 'black',
            color: 'white',
          }}
        >
          <Header />
        </Box>

        
        <Box
          sx={{
            display: 'flex',
            pt: `${HEADER_HEIGHT}px`,
            minHeight: '100vh',
            bgcolor: 'black',
            color: 'white',
            flexDirection: isMobile ? 'column' : 'row',
          }}
        >
       
          {!isMobile && (
            <Box
              sx={{
                width: SIDENAV_WIDTH,
                flexShrink: 0,
                position: 'fixed',
                top: HEADER_HEIGHT,
                left: 0,
                height: `calc(100vh - ${HEADER_HEIGHT}px)`,
                borderRight: '1px solid #444',
                bgcolor: 'black',
                color: 'white',
                zIndex: 1200,
              }}
            >
              <SideNav />
            </Box>
          )}

          
          <Box
            component="main"
            sx={{
              flexGrow: 1,
              ml: isMobile ? 0 : `${SIDENAV_WIDTH}px`,
              
            }}
          >
            <AppRoutes />
          </Box>
        </Box>

      
        <Box sx={{ bgcolor: 'black', color: 'white' }}>
          <Footer />
        </Box>
      </PageTitleProvider>
    </Router>
  );
}

export default App;
