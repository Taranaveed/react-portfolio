import React from 'react';
import { Drawer, List, ListItem, ListItemText } from '@mui/material';
import { Link } from 'react-router-dom';
import useMediaQuery from '@mui/material/useMediaQuery';

const HEADER_HEIGHT = 64;

const SideNav = () => {
  const isMobile = useMediaQuery('(max-width:600px)');
  const navItems = [
    { label: 'Home', path: '/' },
    { label: 'About', path: '/about' },
    { label: 'Education', path: '/education' },
    { label: 'Skills', path: '/skills' },
    { label: 'Projects', path: '/projects' },
    { label: 'Contact', path: '/contact' },
  ];

  return (
    <Drawer
      variant={isMobile ? 'temporary' : 'permanent'}
      open
      sx={{
        width: 150,
        flexShrink: 0,
        '& .MuiDrawer-paper': {
          width: 150,
          boxSizing: 'border-box',
          top: isMobile ? 0 : HEADER_HEIGHT,
          height: isMobile ? '100%' : `calc(100vh - ${HEADER_HEIGHT}px)`,
          backgroundColor: 'black', 
          color: 'white',           
        },
      }}
    >
      <List sx={{ paddingTop: isMobile ? 0 : 2 }}>
        {navItems.map((item) => (
          <ListItem button component={Link} to={item.path} key={item.label} sx={{ '&:hover': { backgroundColor: '#444' } }}>
            <ListItemText primary={item.label} sx={{ color: 'white' }} />
          </ListItem>
        ))}
      </List>
    </Drawer>
  );
};  

export default SideNav;
