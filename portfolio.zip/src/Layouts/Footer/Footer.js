import React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import FacebookIcon from '@mui/icons-material/Facebook';
import InstagramIcon from '@mui/icons-material/Instagram';
import TwitterIcon from '@mui/icons-material/Twitter';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import GitHubIcon from '@mui/icons-material/GitHub';

const Footer = () => (
  <Box
    component="footer"
    sx={{
      textAlign: 'center',
      py: 2,
      backgroundColor: 'black',
      color: 'white',
    }}
  >

    <Box sx={{ mb: 1 }}>
      <IconButton
        component="a"
        href="https://www.facebook.com/"
        target="_blank"
        rel="noopener"
        sx={{ color: 'white' }}
      >
        <FacebookIcon />
      </IconButton>
      <IconButton
        component="a"
        href="https://www.instagram.com/"
        target="_blank"
        rel="noopener"
        sx={{ color: 'white' }}
      >
        <InstagramIcon />
      </IconButton>
      <IconButton
        component="a"
        href="https://www.twitter.com/"
        target="_blank"
        rel="noopener"
        sx={{ color: 'white' }}
      >
        <TwitterIcon />
      </IconButton>
      <IconButton
        component="a"
        href="https://www.linkedin.com/"
        target="_blank"
        rel="noopener"
        sx={{ color: 'white' }}
      >
        <LinkedInIcon />
      </IconButton>
      <IconButton
        component="a"
        href="https://github.com/"
        target="_blank"
        rel="noopener"
        sx={{ color: 'white' }}
      >
        <GitHubIcon />
      </IconButton>
    </Box>

   
  </Box>
);

export default Footer;
