import React from 'react';
import { Box, Typography, Grid, Avatar } from '@mui/material';

const About = () => (
  <Box
    sx={{
      p: 3,
      bgcolor: '#18181B',
      color: 'white',
      minHeight: '100vh',
    }}
  >
    <Box sx={{ mt: 4 }}>
      <Typography variant="h4" fontWeight="bold" gutterBottom textAlign="center">
        About Me
      </Typography>

      <Grid container spacing={4} alignItems="center" justifyContent="center">
      
        <Grid item xs={12} md={4} sx={{ display: 'flex', justifyContent: 'center' }}>
          <Avatar
            alt="Sitara Naveed"
            src="/about.jpeg"
            sx={{ width:'100%', height: 350, borderRadius: 2 }}
            variant="square"
          />
        </Grid>

        
        <Grid item xs={12} md={8} sx={{ width: '600px' }}>
          <Typography paragraph>
            I am Sitara Naveed, a passionate Artificial Intelligence student in my 4th semester at Information Technology University. My journey into the world of AI and technology began with a deep fascination for problem-solving and innovation. From an early age, I was captivated by how technology can transform lives, which led me to pursue a career in AI, software development, and data-driven research.
          </Typography>
          <Typography paragraph>
            Academically, I excelled at Chand Bagh School, specializing in Mathematics and Further Mathematics, which built my strong analytical foundation. Throughout my studies, I have worked on a variety of hands-on projects, including:
          </Typography>
          <Typography paragraph>
            Beyond development, I have a keen interest in research and writing. I also contribute AI-driven articles that break down complex topics into engaging, informative content.
          </Typography>
          <Typography paragraph>
            I strongly believe in lifelong learning and constantly seek opportunities to expand my skill set in AI and software development. I enjoy exploring new technologies and tackling complex problems.
          </Typography>
          <Typography paragraph>
            Looking ahead, I aspire to work on cutting-edge AI solutions that bridge the gap between technology and real-world problems. My goal is to create user-friendly AI applications, enhance automation efficiency, and contribute to the ever-evolving tech industry.
          </Typography>
        </Grid>
      </Grid>
    </Box>
  </Box>
);

export default About;
