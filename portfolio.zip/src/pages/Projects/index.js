import React from 'react';
import ProjectCard from '../../components/ProjectCard';
import { Grid, Typography, Box } from '@mui/material';

const projectData = [
  {
    title: 'Oceanix Project',
    description:
      'A NASA Space Apps Challenge project exploring life in a world without sunlight, based on chemosynthesis.',
    image: '/oceanix.jpeg',
  },
  {
    title: 'Lab02 App',
    description:
      'An Android app that extracts hosts, retrieves IPs, and provides location-based data.',
    image: '/lab02.jpeg',
  },
  {
    title: 'Pong Game',
    description: 'A simple arcade game implementation.',
    image: '/pong.jpeg',
  },
  {
    title: 'Vim Text Editor',
    description:
      'A lightweight, customizable text editor built using C++, inspired by the Vim editor.',
    image: '/vim.jpeg',
  },
  {
    title: 'Stock Management Database',
    description:
      'A database system for managing inventory and stock using SQL and Python.',
    image: '/stock.jpeg',
  },
  {
    title: 'Chess Game',
    description:
      'A chess game implementation using C++, object-oriented programming principles.',
    image: '/chess.jpeg',
  },
  {
    title: 'Imposter Syndrome Research',
    description:
      'Research and testing on imposter syndrome in Pakistan.',
    image: '/imposter.jpeg',
  },
  {
    title: 'Customer Experience Articles',
    description:
      'Articles on improving customer experience and reducing churn using AI.',
    image: '/articles.jpeg',
  },
  {
    title: 'Service Website',
    description: 'A platform offering various professional services.',
    image: '/service.jpeg',
  },
];

  const Projects = () => (
    <Box sx={{ p: 3, bgcolor: '#18181B', color: 'white', minHeight: '100vh' }}>
      <Typography variant="h4" gutterBottom>
        Projects
      </Typography>
      <Grid container spacing={3}>
        {projectData.map((project, index) => (
          <Grid item xs={12} sm={6} md={4} lg={4} xl={4} key={index}>
            <ProjectCard
              title={project.title}
              description={project.description}
              image={project.image}
            />
          </Grid>
        ))}
      </Grid>
    </Box>
  );

export default Projects;
