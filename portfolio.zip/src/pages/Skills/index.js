import React from 'react';
import {
  Box,
  Typography,
  LinearProgress,
  Grid,
  Paper,
} from '@mui/material';

import CodeIcon from '@mui/icons-material/Code';
import DesignServicesIcon from '@mui/icons-material/DesignServices';
import SearchIcon from '@mui/icons-material/Search';
import MemoryIcon from '@mui/icons-material/Memory';
import SchoolIcon from '@mui/icons-material/School';
import PsychologyIcon from '@mui/icons-material/Psychology';
import ArticleIcon from '@mui/icons-material/Article';

const skillsData = {
  technical: [
    { label: 'Website Development', value: 90, icon: <CodeIcon sx={{ color: '#00FFFF' }} /> }, // Aqua
    { label: 'Website Design', value: 85, icon: <DesignServicesIcon sx={{ color: '#FF69B4' }} /> }, // HotPink
    { label: 'SEO & Content Optimization', value: 88, icon: <SearchIcon sx={{ color: '#FFD700' }} /> }, // Gold
    { label: 'AI & Machine Learning', value: 80, icon: <MemoryIcon sx={{ color: '#8A2BE2' }} /> }, // BlueViolet
  ],
  soft: [
    { label: 'Technical Tutoring', value: 95, icon: <SchoolIcon sx={{ color: '#32CD32' }} /> }, // LimeGreen
    { label: 'Problem-Solving', value: 90, icon: <PsychologyIcon sx={{ color: '#FFA500' }} /> }, // Orange
    { label: 'Research & Writing', value: 92, icon: <ArticleIcon sx={{ color: '#00CED1' }} /> }, // DarkTurquoise
  ],
};

const SkillBar = ({ label, value, icon, barColor = 'white' }) => (
  <Box sx={{ mb: 3 }}>
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
      {icon}
      <Typography variant="subtitle1" sx={{ color: 'white' }}>
        {label}
      </Typography>
    </Box>
    <LinearProgress
      variant="determinate"
      value={value}
      sx={{
        height: 20,
        width: 400,
        borderRadius: 5,
        backgroundColor: 'gray',
        '& .MuiLinearProgress-bar': {
          backgroundColor: barColor,
        },
      }}
    />
    <Typography variant="body2" sx={{ color: 'white', mt: 0.5 }}>
      {value}%
    </Typography>
  </Box>
);

const Skills = () => (
  <Box sx={{ p: 3, bgcolor: '#18181B', color: 'white', minHeight: '100vh' }}>
    <Typography variant="h4" gutterBottom>
      Skills
    </Typography>

    <Grid container spacing={4}>
      <Grid item xs={12} md={6}>
        <Paper elevation={3} sx={{ p: 3, bgcolor: '#18181B', color: 'white' }}>
          <Typography variant="h6" gutterBottom>
            Technical Skills
          </Typography>
          {skillsData.technical.map((skill, index) => (
            <SkillBar
              key={index}
              label={skill.label}
              value={skill.value}
              icon={skill.icon}
            />
          ))}
        </Paper>
      </Grid>

      <Grid item xs={12} md={6}>
        <Paper elevation={3} sx={{ p: 3, bgcolor: '#18181B', color: 'white' }}>
          <Typography variant="h6" gutterBottom>
            Soft Skills
          </Typography>
          {skillsData.soft.map((skill, index) => (
            <SkillBar
              key={index}
              label={skill.label}
              value={skill.value}
              icon={skill.icon}
            />
          ))}
        </Paper>
      </Grid>
    </Grid>
  </Box>
);

export default Skills;
