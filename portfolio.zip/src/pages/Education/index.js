import React from 'react';
import {
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Box,
} from '@mui/material';

const Education = () => {
  const educationData = [
    {
      degree: 'Matriculation (Sciences)',
      institution: 'Chand Bagh School',
      details: 'Scored 1048/1100',
      year: '2020',
    },
    {
      degree: 'A-Levels',
      institution: 'Chand Bagh School',
      details: 'Mathematics (A*), Further Mathematics (A), Physics (B)',
      year: '2022',
    },
    {
      degree: 'Bachelor of Science in Artificial Intelligence',
      institution: 'Information Technology University',
      details: 'Currently in 4th Semester',
      year: '2023 - Present',
    },
  ];

  return (
    <Box sx={{ p: 3, bgcolor: '#18181B', color: 'white', height: '100vh' }}>
      <Typography variant="h4" gutterBottom>
        Education
      </Typography>

      <TableContainer component={Paper} sx={{ bgcolor: '#18181B', color: 'white' }}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell sx={{ color: 'white' }}><strong>Degree</strong></TableCell>
              <TableCell sx={{ color: 'white' }}><strong>Institution</strong></TableCell>
              <TableCell sx={{ color: 'white' }}><strong>Details</strong></TableCell>
              <TableCell sx={{ color: 'white' }}><strong>Year</strong></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {educationData.map((row, index) => (
              <TableRow key={index}>
                <TableCell sx={{ color: 'white' }}>{row.degree}</TableCell>
                <TableCell sx={{ color: 'white' }}>{row.institution}</TableCell>
                <TableCell sx={{ color: 'white' }}>{row.details}</TableCell>
                <TableCell sx={{ color: 'white' }}>{row.year}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default Education;
