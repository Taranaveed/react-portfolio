import React from 'react';
import { Box, Typography } from '@mui/material';

const Home = () => (
  <Box
    sx={{
      height: '100vh',
      backgroundColor: 'black',
      color: 'white',
      backgroundImage: 'url(/heroImage.jpeg)',
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundRepeat: 'no-repeat',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center', 
      textAlign: 'center', 
      px: 2, 
    }}
  >
    <Typography variant="h3" fontWeight="bold" gutterBottom>
    Hi, I'm Sitara Naveed
    </Typography>

    <Typography variant="h4" fontWeight="bold" gutterBottom>
    An AI Student, Developer, and Content Writer
    </Typography>

    
  </Box>
);

export default Home;
