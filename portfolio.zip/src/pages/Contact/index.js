import React from 'react';
import ContactForm from '../../components/ContactForm';

const Contact = () => <ContactForm />;

export default Contact;