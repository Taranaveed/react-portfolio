import React from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { TextField, Button, Box, Typography, Grid } from '@mui/material';

const ContactForm = () => {
  const formik = useFormik({
    initialValues: { name: '', email: '', subject: '', message: '' },
    validationSchema: Yup.object({
      name: Yup.string().required('Required'),
      email: Yup.string().email('Invalid email').required('Required'),
      subject: Yup.string().required('Required'),
      message: Yup.string().required('Required'),
    }),
    onSubmit: (values) => alert(JSON.stringify(values, null, 2)),
  });

  return (
    <Box sx={{ bgcolor: '#18181B', color: 'white', py: 6, px: 3, minHeight: '100vh' }}>
      <Typography variant="h4" gutterBottom sx={{ color: 'white' }}>
        Contact Me
      </Typography>

      <Grid container spacing={4} alignItems="flex-start">
   
        <Grid item xs={12} md={6}>
          <Box
            sx={{
              height: 450,
              width: 500,
              borderRadius: 1,
              overflow: 'hidden',
              boxShadow: 3,
            }}
          >
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.012384717294!2d-122.42134948468192!3d37.77492927975924!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8085809c56448f67%3A0x349b77ffdc95f83b!2sSan+Francisco+City+Hall!5e0!3m2!1sen!2sus!4v1635233511865!5m2!1sen!2sus"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
            ></iframe>
          </Box>
        </Grid>

     
        <Grid item xs={12} md={6}>
          <Box component="form" onSubmit={formik.handleSubmit} sx={{ maxWidth: 500 }}>
            {['name', 'email', 'subject', 'message'].map((field, i) => (
              <TextField
                key={i}
                margin="normal"
                label={
                  field === 'message' ? 'Project Details' : field.charAt(0).toUpperCase() + field.slice(1)
                }
                multiline={field === 'message'}
                rows={field === 'message' ? 4 : undefined}
                {...formik.getFieldProps(field)}
                error={formik.touched[field] && Boolean(formik.errors[field])}
                helperText={formik.touched[field] && formik.errors[field]}
                sx={{
                  width: '100%',
                  '& .MuiInputBase-root': {
                    color: 'white',
                  },
                  '& .MuiInputLabel-root': {
                    color: 'gray',
                  },
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderColor: 'gray',
                    },
                    '&:hover fieldset': {
                      borderColor: 'green',
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: 'green',
                    },
                  },
                  '& .MuiFormHelperText-root': {
                    color: 'gray',
                  },
                }}
              />
            ))}

            <Button
              type="submit"
              variant="contained"
              sx={{
                mt: 2,
                bgcolor: 'green',
                color: 'black',
                '&:hover': {
                  bgcolor: '#00cc00',
                },
              }}
            >
              Submit
            </Button>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
};

export default ContactForm;
