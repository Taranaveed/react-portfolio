import React from 'react';
import { Card, CardContent, CardMedia, Typography, Box } from '@mui/material';

const ProjectCard = ({ title, description, image }) => (
  <Card
    sx={{
      mb: 2,
      width: 300, 
      height: 350, 
      transition: 'transform 0.3s',
      '&:hover': { transform: 'scale(1.05)' },
      display: 'flex',
      flexDirection: 'column',
      backgroundColor: 'black', 
      color: 'white', 
    }}
  >
    {image && (
      <Box sx={{ p: 1, pb: 0 }}>
        <CardMedia
          component="img"
          sx={{
            height: 200,
            width: '100%',
            objectFit: 'cover',
            borderRadius: 1,
            color: 'white', 
          }}
          image={image}
          alt={title}
        />
      </Box>
    )}

    <CardContent sx={{ flex: 1 }}>
      <Typography variant="h6" gutterBottom>
        {title}
      </Typography>
      <Typography variant="body2" color= "white">
        {description}
      </Typography>
    </CardContent>
  </Card>
);

export default ProjectCard;
